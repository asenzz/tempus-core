create view v_user_datasets
            (id, dataset_name, user_name, main_input_queue_table_name, aux_input_queues_table_names, priority, description, levels, deconstruction, max_gap, is_active, gradients,
             max_chunk_size, multistep, linked_user_name, user_priority)
as
SELECT DISTINCT id,
                dataset_name,
                user_name,
                main_input_queue_table_name,
                aux_input_queues_table_names,
                priority,
                description,
                levels,
                deconstruction,
                max_gap,
                is_active,
                gradients,
                max_chunk_size,
                multistep,
                linked_user_name,
                user_priority
FROM (SELECT ds.id,
             ds.dataset_name,
             ds.user_name,
             ds.main_input_queue_table_name,
             ds.aux_input_queues_table_names,
             ds.priority,
             ds.description,
             ds.levels,
             ds.deconstruction,
             ds.max_gap,
             ds.is_active,
             ds.gradients,
             ds.max_chunk_size,
             ds.multistep,
             ua.username AS linked_user_name,
             ua.priority AS user_priority
      FROM datasets ds
               JOIN user_datasets ud ON ds.id = ud.dataset_id
               JOIN userauth ua ON ua.user_id = ud.user_id
      WHERE ds.is_active = true
      UNION ALL
      SELECT ds.id,
             ds.dataset_name,
             ds.user_name,
             ds.main_input_queue_table_name,
             ds.aux_input_queues_table_names,
             ds.priority,
             ds.description,
             ds.levels,
             ds.deconstruction,
             ds.max_gap,
             ds.is_active,
             ds.gradients,
             ds.max_chunk_size,
             ds.multistep,
             ua.username AS linked_user_name,
             ua.priority AS user_priority
      FROM datasets ds
               JOIN userauth ua ON ua.username = ds.user_name
      WHERE ds.is_active = true) all_ds
ORDER BY user_priority DESC, priority DESC;

alter table v_user_datasets
    owner to svrwave;

