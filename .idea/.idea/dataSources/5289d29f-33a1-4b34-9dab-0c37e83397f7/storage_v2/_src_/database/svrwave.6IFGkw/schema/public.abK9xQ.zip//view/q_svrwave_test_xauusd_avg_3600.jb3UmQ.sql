create view q_svrwave_test_xauusd_avg_3600(value_time, update_time, tick_volume, xauusd_avg_bid, xauusd_avg_ask) as
SELECT value_time,
       update_time,
       tick_volume,
       xauusd_avg_bid,
       xauusd_avg_ask
FROM (SELECT q_svrwave_xauusd_avg_3600.value_time,
             q_svrwave_xauusd_avg_3600.update_time,
             q_svrwave_xauusd_avg_3600.tick_volume,
             q_svrwave_xauusd_avg_3600.xauusd_avg_bid,
             q_svrwave_xauusd_avg_3600.xauusd_avg_ask
      FROM q_svrwave_xauusd_avg_3600
      WHERE q_svrwave_xauusd_avg_3600.value_time < '2025-01-13 01:00:00'::timestamp without time zone
      ORDER BY q_svrwave_xauusd_avg_3600.value_time DESC
      LIMIT 4550) unnamed_subquery
ORDER BY value_time;

alter table q_svrwave_test_xauusd_avg_3600
    owner to svrwave;

