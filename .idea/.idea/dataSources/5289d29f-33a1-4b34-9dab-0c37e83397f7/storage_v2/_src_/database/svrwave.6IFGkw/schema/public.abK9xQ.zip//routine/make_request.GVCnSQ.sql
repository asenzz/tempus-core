create function make_request(user_name text, dataset_id bigint, value_time_start timestamp without time zone, value_time_end timestamp without time zone, resolution interval, column_values text[]) returns bigint
    language plpgsql
as
$$
DECLARE
    request_id BIGINT;
BEGIN
    request_id := nextval('request_id_seq');
    INSERT INTO multival_requests
    VALUES (request_id, dataset_id, user_name, now(), value_time_start, value_time_end, column_values, false,
            resolution)
    ON CONFLICT DO NOTHING;
    RETURN request_id;
END;
$$;

alter function make_request(text, bigint, timestamp, timestamp, interval, text[]) owner to svrwave;

