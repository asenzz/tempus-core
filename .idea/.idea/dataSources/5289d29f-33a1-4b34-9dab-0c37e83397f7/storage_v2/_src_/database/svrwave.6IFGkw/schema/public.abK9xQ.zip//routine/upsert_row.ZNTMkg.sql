create function upsert_row(table_name text, column_values jsonb) returns void
    language plpgsql
as
$$
DECLARE
    column_names TEXT;
    column_data TEXT;
    update_data TEXT;
BEGIN
    -- Construct the column names and data from the JSONB object
    column_names := string_agg(quote_ident(key), ', ') 
                    FROM jsonb_object_keys(column_values) AS key;
    column_data := string_agg(quote_literal(value), ', ') 
                   FROM jsonb_each_text(column_values) AS kv(key, value);

    -- Construct the ON CONFLICT update clause
    update_data := string_agg(quote_ident(key) || ' = EXCLUDED.' || quote_ident(key), ', ') 
                   FROM jsonb_object_keys(column_values) AS key;

    -- Build the dynamic SQL for upsert
    EXECUTE format(
        'INSERT INTO %I (%s) VALUES (%s) ON CONFLICT (value_time) DO UPDATE SET %s;',
        table_name,
        column_names,
        column_data,
        update_data
    );
END;
$$;

alter function upsert_row(text, jsonb) owner to svrwave;

