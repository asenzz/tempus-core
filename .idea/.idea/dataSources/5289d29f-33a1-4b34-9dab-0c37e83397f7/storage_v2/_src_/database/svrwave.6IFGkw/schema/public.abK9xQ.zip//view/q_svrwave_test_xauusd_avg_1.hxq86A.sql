create view q_svrwave_test_xauusd_avg_1(value_time, update_time, tick_volume, xauusd_avg_bid, xauusd_avg_ask) as
SELECT value_time,
       update_time,
       tick_volume,
       xauusd_avg_bid,
       xauusd_avg_ask
FROM (SELECT q_svrwave_xauusd_avg_1.value_time,
             q_svrwave_xauusd_avg_1.update_time,
             q_svrwave_xauusd_avg_1.tick_volume,
             q_svrwave_xauusd_avg_1.xauusd_avg_bid,
             q_svrwave_xauusd_avg_1.xauusd_avg_ask
      FROM q_svrwave_xauusd_avg_1
      WHERE q_svrwave_xauusd_avg_1.value_time < '2025-01-13 01:00:00'::timestamp without time zone
      ORDER BY q_svrwave_xauusd_avg_1.value_time DESC
      LIMIT (4550 * 3600)) unnamed_subquery
ORDER BY value_time;

alter table q_svrwave_test_xauusd_avg_1
    owner to svrwave;

