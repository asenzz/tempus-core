create view v_user_datasets
            (id, dataset_name, user_name, main_input_queue_table_name, aux_input_queues_table_names, priority,
             description, swt_levels, swt_wavelet_name, max_gap, is_active, linked_user_name, user_priority)
as
SELECT DISTINCT all_ds.id,
                all_ds.dataset_name,
                all_ds.user_name,
                all_ds.main_input_queue_table_name,
                all_ds.aux_input_queues_table_names,
                all_ds.priority,
                all_ds.description,
                all_ds.swt_levels,
                all_ds.swt_wavelet_name,
                all_ds.max_gap,
                all_ds.is_active,
                all_ds.linked_user_name,
                all_ds.user_priority
FROM (SELECT ds.id,
             ds.dataset_name,
             ds.user_name,
             ds.main_input_queue_table_name,
             ds.aux_input_queues_table_names,
             ds.priority,
             ds.description,
             ds.swt_levels,
             ds.swt_wavelet_name,
             ds.max_gap,
             ds.is_active,
             ua.username AS linked_user_name,
             ua.priority AS user_priority
      FROM datasets ds
               JOIN user_datasets ud ON ds.id = ud.dataset_id
               JOIN userauth ua ON ua.user_id = ud.user_id
      WHERE ds.is_active = true
      UNION ALL
      SELECT ds.id,
             ds.dataset_name,
             ds.user_name,
             ds.main_input_queue_table_name,
             ds.aux_input_queues_table_names,
             ds.priority,
             ds.description,
             ds.swt_levels,
             ds.swt_wavelet_name,
             ds.max_gap,
             ds.is_active,
             ua.username AS linked_user_name,
             ua.priority AS user_priority
      FROM datasets ds
               JOIN userauth ua ON ua.username = ds.user_name
      WHERE ds.is_active = true) all_ds
ORDER BY all_ds.user_priority DESC, all_ds.priority DESC;

alter table v_user_datasets
    owner to svrwave;

