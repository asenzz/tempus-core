create function cleanup_queue(tbl regclass, value_times timestamp without time zone[]) returns void
    language plpgsql
as
$$
BEGIN
                EXECUTE format('delete from %s q1 where exists (select 1 from unnest(%L::timestamp[]) tm where tm = q1.value_time)', tbl, value_times);
            END
$$;

alter function cleanup_queue(regclass, timestamp without time zone[]) owner to tempustest;

