create function mark_interval_reconciled("tableName" text, "startTime" timestamp without time zone, "endTime" timestamp without time zone) returns void
    language plpgsql
as
$$
DECLARE
    rownum integer;
    cur_start  timestamp without time zone;
    cur_end  timestamp without time zone;
BEGIN
    SELECT INTO rownum count(1)
    FROM input_queue_reconciled_hours
    WHERE table_name = "tableName";

    IF rownum > 0 THEN
	SELECT into cur_start min(start_time)
	FROM input_queue_reconciled_hours
        WHERE table_name = "tableName";
	IF "startTime" < cur_start THEN
	    cur_start := "startTime";
	END IF;

	SELECT into cur_end max(end_time)
	FROM input_queue_reconciled_hours
        WHERE table_name = "tableName";
	IF "endTime" > cur_end THEN
	    cur_end := "endTime";
	END IF;
        
	update input_queue_reconciled_hours 
	set last_request_time = now(), start_time = cur_start, end_time=cur_end
	WHERE table_name = "tableName";
    ELSE
	insert into input_queue_reconciled_hours (table_name, start_time, end_time, last_request_time)
	values ("tableName", "startTime", "endTime", now());
    END IF;
END;
$$;

alter function mark_interval_reconciled(text, timestamp, timestamp) owner to tempustest;

