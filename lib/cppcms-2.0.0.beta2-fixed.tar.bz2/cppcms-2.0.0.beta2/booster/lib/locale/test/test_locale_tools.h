//
//  Copyright (c) 2009-2011 Artyom Beilis (Tonkikh)
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef BOOSTER_LOCLAE_TEST_LOCALE_TOOLS_HPP
#define BOOSTER_LOCLAE_TEST_LOCALE_TOOLS_HPP

#include <booster/locale/encoding.h>

#include <fstream>
#include <stdlib.h>
#include <stdio.h>

template<typename Char>
std::basic_string<Char> to_correct_string(std::string const &e,std::locale /*l*/)
{
    return booster::locale::conv::to_utf<Char>(e,"UTF-8");
}


template<>
inline std::string to_correct_string(std::string const &e,std::locale l)
{
    return booster::locale::conv::from_utf(e,l);
}

bool has_std_locale(std::string const &name)
{
    try {
        std::locale tmp(name.c_str());
        return true;
    }
    catch(...) {
        return false;
    }
}

inline bool test_std_supports_SJIS_codecvt(std::string const &locale_name)
{
    bool res = true;
    {
    // Japan in Shift JIS/cp932
        char const *japan_932 = "\x93\xfa\x96\x7b";
        std::ofstream f("test-siftjis.txt");
        f<<japan_932;
        f.close();		
    }
    try {
        std::wfstream test;
        test.imbue(std::locale(locale_name.c_str()));
        test.open("test-siftjis.txt");
        // Japan in Unicode
        std::wstring cmp = L"\u65e5\u672c";
        std::wstring ref;
        test >> ref;
        res = ref == cmp;
    }
    catch(std::exception const &)
    {
        res = false;
    }
    remove("test-siftjis.txt");
    return res;
}

std::string get_std_name(std::string const &name,std::string *real_name = 0)
{
    if(has_std_locale(name)) {
        if(real_name)
            *real_name = name;
        return name;
    }

    #ifdef BOOSTER_WIN_NATIVE
    bool utf8=name.find("UTF-8")!=std::string::npos;

    if(name=="en_US.UTF-8" || name == "en_US.ISO8859-1") {
        if(has_std_locale("English_United States.1252")) {
            if(real_name) 
                *real_name = "English_United States.1252";
            return utf8 ? name : "en_US.windows-1252";
        }
        return "";
    }
    else if(name=="he_IL.UTF-8" || name == "he_IL.ISO8859-8")  {
        if(has_std_locale("Hebrew_Israel.1255")) {
            if(real_name) 
                *real_name = "Hebrew_Israel.1255";
            return utf8 ? name : "he_IL.windows-1255";
            return name;
        }
    }
    else if(name=="ru_RU.UTF-8")  {
        if(has_std_locale("Russian_Russia.1251")) {
            if(real_name) 
                *real_name = "Russian_Russia.1251";
            return name;
        }
    }
    else if(name == "tr_TR.UTF-8") {
        if(has_std_locale("Turkish_Turkey.1254")) {
            if(real_name) 
                *real_name = "Turkish_Turkey.1254";
            return name;
        }
    }
    if(name == "ja_JP.SJIS") {
        if(has_std_locale("Japanese_Japan.932")) {
            if(real_name) 
                *real_name = "Japanese_Japan.932";
            return name;
        }
        return "";
    }
    #endif
    return "";
}



#endif
// vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4
